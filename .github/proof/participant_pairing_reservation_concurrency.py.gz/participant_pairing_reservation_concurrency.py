import asyncio
import json
import os
import sys
import time
import traceback
import uuid

import asyncpg

DSN = os.environ["PROOF_DATABASE_URL"]
REPORT_PATH = os.environ.get("PROOF_REPORT_PATH", "/tmp/participant-pairing-proof.txt")
TERMINAL = ("ENDED", "ABANDONED", "FAILED", "COMPLETED")
NON_TERMINAL = ("PENDING", "ACTIVE", "PAUSED")
VERIFY_SQL = """
SELECT participant_id::text, count(*)::int
FROM participant_pairing_reservations
WHERE released_at IS NULL
GROUP BY participant_id
HAVING count(*) > 1
ORDER BY participant_id
""".strip()

TEST_NAMES = {
    1: "same participant concurrently reserved for two pairings",
    2: "A/B versus B/A role inversion",
    3: "two independent pairings succeed concurrently",
    4: "partial overlap between candidate pairings",
    5: "simultaneous acquisition of exact same pair",
    6: "rollback after first reservation insert",
    7: "conflict while acquiring second participant",
    8: "release followed by legitimate reacquisition",
    9: "concurrent release and reacquire race for one participant",
    10: "idempotent release predicate",
    11: "concurrent terminal/release attempts have one winner",
    12: "ascending UUID ordering under overlapping concurrent load",
    13: "canonical ordering survives inverted A/B role metadata",
    14: "first-key contention serializes without deadlock",
    15: "released historical row coexists with one new active reservation",
    16: "multiple released historical reservations remain valid",
    17: "duplicate active insert within same pairing hits primary key",
    18: "duplicate active insert across matches hits partial unique index",
    19: "rollback after both acquisition inserts removes both",
    20: "terminal transaction rollback preserves conversation and reservations",
    21: "terminal commit atomically exposes terminal status plus both releases",
    22: "PENDING conversation keeps reservations held",
    23: "ACTIVE conversation keeps reservations held",
    24: "PAUSED conversation keeps reservations held",
    25: "all four terminal statuses release reservations",
    26: "full-pair release/reacquire race serializes correctly",
    27: "released_at temporal CHECK rejects pre-acquisition release time",
    28: "high-concurrency independent canonical acquisitions",
    29: "NEGATIVE CONTROL unordered P/Q versus Q/P deadlocks",
}


CONCURRENT_SESSIONS = {
    1:2,2:2,3:2,4:2,5:2,6:1,7:2,8:1,9:2,10:1,11:2,12:5,13:2,14:2,15:1,16:1,17:1,18:1,19:1,20:1,21:2,22:1,23:1,24:1,25:1,26:2,27:1,28:20,29:2
}

class InvariantFailure(Exception):
    pass

class HarnessBlocked(Exception):
    pass

_report = None


def log(line=""):
    print(line, flush=True)
    _report.write(line + "\n")
    _report.flush()


def q(value):
    if isinstance(value, uuid.UUID):
        return str(value)
    return value


def params_text(args):
    return json.dumps([q(a) for a in args], default=str)


def err_text(exc):
    return json.dumps({
        "type": type(exc).__name__,
        "sqlstate": getattr(exc, "sqlstate", None),
        "constraint": getattr(exc, "constraint_name", None),
        "message": str(exc),
    }, sort_keys=True)


def assert_true(condition, message):
    if not condition:
        raise InvariantFailure(message)


def u(n):
    return uuid.UUID(int=n)


def m(n):
    return uuid.UUID(int=10_000 + n)


async def connect(label):
    conn = await asyncpg.connect(DSN, command_timeout=15)
    await conn.execute("SELECT set_config('application_name', $1, false)", f"pairing-proof-{label}")
    return conn


async def sql(conn, label, statement, *args):
    compact = " ".join(statement.strip().split())
    log(f"SQL[{label}] {compact} params={params_text(args)}")
    started = time.monotonic()
    try:
        result = await conn.execute(statement, *args)
        elapsed = (time.monotonic() - started) * 1000
        log(f"RAW[{label}] result={result!r} elapsed_ms={elapsed:.1f}")
        return result
    except Exception as exc:
        elapsed = (time.monotonic() - started) * 1000
        log(f"RAW[{label}] ERROR={err_text(exc)} elapsed_ms={elapsed:.1f}")
        raise


async def fetch(conn, label, statement, *args):
    compact = " ".join(statement.strip().split())
    log(f"SQL[{label}] {compact} params={params_text(args)}")
    started = time.monotonic()
    try:
        rows = await conn.fetch(statement, *args)
        elapsed = (time.monotonic() - started) * 1000
        raw = [dict(r) for r in rows]
        log(f"RAW[{label}] rows={json.dumps(raw, default=str, sort_keys=True)} elapsed_ms={elapsed:.1f}")
        return rows
    except Exception as exc:
        elapsed = (time.monotonic() - started) * 1000
        log(f"RAW[{label}] ERROR={err_text(exc)} elapsed_ms={elapsed:.1f}")
        raise


async def begin(conn, label):
    log(f"TX[{label}] BEGIN ISOLATION LEVEL READ COMMITTED")
    tr = conn.transaction(isolation="read_committed")
    await tr.start()
    await conn.execute("SET LOCAL statement_timeout = '10s'")
    return tr


async def commit(tr, label):
    started = time.monotonic()
    await tr.commit()
    log(f"TX[{label}] COMMIT elapsed_ms={(time.monotonic()-started)*1000:.1f}")


async def rollback(tr, label):
    started = time.monotonic()
    await tr.rollback()
    log(f"TX[{label}] ROLLBACK elapsed_ms={(time.monotonic()-started)*1000:.1f}")


SCHEMA_SQL = """
DROP TABLE IF EXISTS participant_pairing_reservations CASCADE;
DROP TABLE IF EXISTS conversations CASCADE;
DROP TABLE IF EXISTS matches CASCADE;
DROP TABLE IF EXISTS participants CASCADE;

CREATE TABLE participants (
  participant_id uuid PRIMARY KEY
);

CREATE TABLE matches (
  match_id uuid PRIMARY KEY
);

CREATE TABLE conversations (
  match_id uuid PRIMARY KEY REFERENCES matches(match_id),
  conversation_status text NOT NULL CHECK (
    conversation_status IN ('PENDING','ACTIVE','PAUSED','ENDED','ABANDONED','FAILED','COMPLETED')
  )
);

CREATE TABLE participant_pairing_reservations (
  match_id uuid NOT NULL REFERENCES matches(match_id),
  participant_id uuid NOT NULL REFERENCES participants(participant_id),
  acquired_at timestamptz NOT NULL,
  released_at timestamptz NULL,
  PRIMARY KEY (match_id, participant_id),
  CHECK (released_at IS NULL OR released_at >= acquired_at)
);

CREATE UNIQUE INDEX participant_pairing_reservations_one_active_per_participant
ON participant_pairing_reservations(participant_id)
WHERE released_at IS NULL;
""".strip()


async def reset_data():
    conn = await connect("reset")
    try:
        await sql(conn, "reset", "TRUNCATE participant_pairing_reservations, conversations, matches, participants CASCADE")
    finally:
        await conn.close()


async def seed(participants, matches, statuses=None):
    statuses = statuses or {}
    conn = await connect("seed")
    tr = await begin(conn, "seed")
    try:
        for pid in sorted(set(participants), key=str):
            await sql(conn, "seed", "INSERT INTO participants(participant_id) VALUES($1)", pid)
        for mid in matches:
            await sql(conn, "seed", "INSERT INTO matches(match_id) VALUES($1)", mid)
            status = statuses.get(mid, "PENDING")
            await sql(conn, "seed", "INSERT INTO conversations(match_id, conversation_status) VALUES($1,$2)", mid, status)
        await commit(tr, "seed")
    except Exception:
        await rollback(tr, "seed")
        raise
    finally:
        await conn.close()


async def insert_reservation(conn, label, mid, pid):
    return await sql(
        conn, label,
        "INSERT INTO participant_pairing_reservations(match_id, participant_id, acquired_at, released_at) VALUES($1,$2,clock_timestamp(),NULL)",
        mid, pid,
    )


async def acquire_pair(conn, label, mid, pids, ordered=True):
    order = sorted(pids, key=str) if ordered else list(pids)
    log(f"ORDER[{label}] participant_ids={[str(x) for x in order]} ordered={ordered}")
    for pid in order:
        await insert_reservation(conn, label, mid, pid)


async def active_rows(participant_id=None):
    conn = await connect("inspect-active")
    try:
        if participant_id is None:
            rows = await fetch(conn, "inspect-active", "SELECT match_id::text, participant_id::text, acquired_at::text, released_at::text FROM participant_pairing_reservations ORDER BY participant_id, match_id")
        else:
            rows = await fetch(conn, "inspect-active", "SELECT match_id::text, participant_id::text, acquired_at::text, released_at::text FROM participant_pairing_reservations WHERE participant_id=$1 ORDER BY match_id", participant_id)
        return rows
    finally:
        await conn.close()


async def verify_uniqueness(test_no):
    conn = await connect(f"verify-{test_no}")
    try:
        rows = await fetch(conn, f"verify-{test_no}", VERIFY_SQL)
        log(f"VERIFY TEST {test_no}: duplicate_active_rows={len(rows)} expected=0")
        assert_true(len(rows) == 0, f"test {test_no}: duplicate active reservation invariant violated")
    finally:
        await conn.close()


async def terminal_release_tx(conn, label, mid, target_status, hold_event=None, proceed_event=None):
    assert_true(target_status in TERMINAL, f"invalid terminal target {target_status}")
    tr = await begin(conn, label)
    try:
        rows = await fetch(
            conn, label,
            "UPDATE conversations SET conversation_status=$2 WHERE match_id=$1 AND conversation_status IN ('PENDING','ACTIVE','PAUSED') RETURNING conversation_status",
            mid, target_status,
        )
        if len(rows) != 1:
            await rollback(tr, label)
            return {"won": False, "released": [], "status_rows": len(rows)}
        released = await fetch(
            conn, label,
            "UPDATE participant_pairing_reservations SET released_at=clock_timestamp() WHERE match_id=$1 AND released_at IS NULL RETURNING participant_id::text",
            mid,
        )
        if hold_event is not None:
            hold_event.set()
        if proceed_event is not None:
            await proceed_event.wait()
        await commit(tr, label)
        return {"won": True, "released": [r["participant_id"] for r in released], "status_rows": 1}
    except Exception:
        try:
            await rollback(tr, label)
        except Exception:
            pass
        raise


async def establish_pair(mid, pids, status="PENDING"):
    await seed(pids, [mid], {mid: status})
    conn = await connect("establish")
    tr = await begin(conn, "establish")
    try:
        await acquire_pair(conn, "establish", mid, pids, ordered=True)
        await commit(tr, "establish")
    except Exception:
        await rollback(tr, "establish")
        raise
    finally:
        await conn.close()


async def concurrent_conflict(mid1, pair1, mid2, pair2, expect_block=True):
    c1 = await connect("T1")
    c2 = await connect("T2")
    tr1 = await begin(c1, "T1")
    try:
        await acquire_pair(c1, "T1", mid1, pair1, ordered=True)
        async def t2_run():
            tr2 = await begin(c2, "T2")
            try:
                await acquire_pair(c2, "T2", mid2, pair2, ordered=True)
                await commit(tr2, "T2")
                return {"ok": True}
            except Exception as exc:
                try:
                    await rollback(tr2, "T2")
                except Exception:
                    pass
                return {"ok": False, "error": exc}
        task = asyncio.create_task(t2_run())
        await asyncio.sleep(0.30)
        blocked = not task.done()
        log(f"OBSERVED T2 blocked_after_300ms={blocked}")
        if expect_block:
            assert_true(blocked, "conflicting transaction did not block on uncommitted active reservation")
        await commit(tr1, "T1")
        result = await asyncio.wait_for(task, timeout=10)
        return blocked, result
    except Exception:
        try:
            await rollback(tr1, "T1")
        except Exception:
            pass
        raise
    finally:
        await c1.close()
        await c2.close()


async def test1():
    await reset_data(); P,Q,R=u(1),u(2),u(3); M1,M2=m(1),m(2)
    await seed([P,Q,R],[M1,M2])
    blocked,res=await concurrent_conflict(M1,[P,Q],M2,[P,R])
    assert_true(not res["ok"] and getattr(res["error"],"sqlstate",None)=="23505", "expected 23505 for shared participant")
    await verify_uniqueness(1)


async def test2():
    await reset_data(); P,Q,R=u(10),u(20),u(30); M1,M2=m(10),m(20)
    log(f"ROLE META M1: participant_a={P} participant_b={Q}; M2: participant_a={R} participant_b={P}")
    await seed([P,Q,R],[M1,M2])
    _,res=await concurrent_conflict(M1,[P,Q],M2,[R,P])
    assert_true(not res["ok"] and getattr(res["error"],"sqlstate",None)=="23505", "role inversion escaped normalized uniqueness")
    await verify_uniqueness(2)


async def test3():
    await reset_data(); A,B,C,D=u(101),u(102),u(201),u(202); M1,M2=m(31),m(32)
    await seed([A,B,C,D],[M1,M2])
    async def worker(label,mid,pair):
        c=await connect(label); tr=await begin(c,label)
        try:
            await acquire_pair(c,label,mid,pair,True); await asyncio.sleep(0.25); await commit(tr,label); return "ok"
        finally: await c.close()
    r=await asyncio.gather(worker("T1",M1,[A,B]), worker("T2",M2,[C,D]))
    assert_true(r==["ok","ok"],"independent pairings did not both commit")
    await verify_uniqueness(3)


async def test4():
    await reset_data(); A,B,C=u(301),u(302),u(303); M1,M2=m(41),m(42)
    await seed([A,B,C],[M1,M2])
    _,res=await concurrent_conflict(M1,[A,B],M2,[B,C])
    assert_true(not res["ok"] and getattr(res["error"],"sqlstate",None)=="23505","partial overlap was not rejected")
    await verify_uniqueness(4)


async def test5():
    await reset_data(); A,B=u(401),u(402); M1,M2=m(51),m(52)
    await seed([A,B],[M1,M2])
    _,res=await concurrent_conflict(M1,[A,B],M2,[A,B])
    assert_true(not res["ok"] and getattr(res["error"],"sqlstate",None)=="23505","same-pair concurrent loser did not get 23505")
    await verify_uniqueness(5)


async def test6():
    await reset_data(); A,B=u(501),u(502); M1=m(61)
    await seed([A,B],[M1]); c=await connect("T1"); tr=await begin(c,"T1")
    await insert_reservation(c,"T1",M1,A); await rollback(tr,"T1"); await c.close()
    rows=await active_rows(); assert_true(len(rows)==0,"first inserted reservation survived rollback")
    await verify_uniqueness(6)


async def test7():
    await reset_data(); A,B,C=u(601),u(602),u(603); M1,M2=m(71),m(72)
    await seed([A,B,C],[M1,M2])
    c1=await connect("T1"); c2=await connect("T2"); tr1=await begin(c1,"T1")
    await acquire_pair(c1,"T1",M1,[A,C],True)
    async def t2():
        tr2=await begin(c2,"T2")
        try:
            await insert_reservation(c2,"T2",M2,B)
            task=asyncio.create_task(insert_reservation(c2,"T2-second",M2,C))
            await asyncio.sleep(.30); blocked=not task.done(); log(f"OBSERVED second-key blocked_after_300ms={blocked}")
            assert_true(blocked,"second participant conflict did not block")
            return tr2,task
        except Exception:
            await rollback(tr2,"T2"); raise
    tr2,task=await t2(); await commit(tr1,"T1")
    try:
        await task; raise InvariantFailure("second participant conflict unexpectedly succeeded")
    except asyncpg.PostgresError as exc:
        log(f"RAW[T2-second] post-unblock ERROR={err_text(exc)}")
        assert_true(exc.sqlstate=="23505","second participant conflict did not yield 23505")
        await rollback(tr2,"T2")
    await c1.close(); await c2.close()
    conn=await connect("inspect"); rows=await fetch(conn,"inspect","SELECT participant_id::text FROM participant_pairing_reservations WHERE match_id=$1",M2); await conn.close()
    assert_true(len(rows)==0,"T2 first reservation did not roll back after second-key conflict")
    await verify_uniqueness(7)


async def test8():
    await reset_data(); A,B,C=u(701),u(702),u(703); M1,M2=m(81),m(82)
    await establish_pair(M1,[A,B],"ACTIVE"); await seed([C],[M2])
    c=await connect("release"); result=await terminal_release_tx(c,"release",M1,"ENDED"); await c.close()
    assert_true(result["won"] and len(result["released"])==2,"terminal release did not release both")
    c=await connect("reacquire"); tr=await begin(c,"reacquire"); await acquire_pair(c,"reacquire",M2,[A,C],True); await commit(tr,"reacquire"); await c.close()
    await verify_uniqueness(8)


async def test9():
    await reset_data(); A,B,C=u(801),u(802),u(803); M1,M2=m(91),m(92)
    await establish_pair(M1,[A,B],"ACTIVE"); await seed([C],[M2])
    c1=await connect("release-T1"); c2=await connect("reacquire-T2")
    hold=asyncio.Event(); proceed=asyncio.Event()
    t1=asyncio.create_task(terminal_release_tx(c1,"release-T1",M1,"ENDED",hold,proceed)); await hold.wait()
    async def reacquire():
        tr=await begin(c2,"reacquire-T2")
        try:
            await acquire_pair(c2,"reacquire-T2",M2,[A,C],True); await commit(tr,"reacquire-T2"); return {"ok":True}
        except Exception as exc:
            await rollback(tr,"reacquire-T2"); return {"ok":False,"error":exc}
    t2=asyncio.create_task(reacquire()); await asyncio.sleep(.30); blocked=not t2.done(); log(f"OBSERVED reacquire blocked_after_300ms={blocked}"); assert_true(blocked,"reacquire did not block behind uncommitted release")
    proceed.set(); r1=await t1; r2=await t2; await c1.close(); await c2.close()
    assert_true(r1["won"] and r2["ok"],"release/reacquire race did not serialize to success")
    await verify_uniqueness(9)


async def test10():
    await reset_data(); A,B=u(901),u(902); M1=m(101)
    await establish_pair(M1,[A,B],"ACTIVE"); c=await connect("first-release"); r=await terminal_release_tx(c,"first-release",M1,"ENDED"); await c.close(); assert_true(len(r["released"])==2,"first release count !=2")
    c=await connect("idempotent"); tr=await begin(c,"idempotent")
    rows=await fetch(c,"idempotent","UPDATE participant_pairing_reservations SET released_at=clock_timestamp() WHERE match_id=$1 AND released_at IS NULL RETURNING participant_id::text",M1)
    await commit(tr,"idempotent"); await c.close(); assert_true(len(rows)==0,"idempotent release updated already-released rows")
    await verify_uniqueness(10)


async def test11():
    await reset_data(); A,B=u(1001),u(1002); M1=m(111)
    await establish_pair(M1,[A,B],"ACTIVE"); c1=await connect("T1"); c2=await connect("T2"); hold=asyncio.Event(); proceed=asyncio.Event()
    t1=asyncio.create_task(terminal_release_tx(c1,"T1",M1,"ENDED",hold,proceed)); await hold.wait()
    t2=asyncio.create_task(terminal_release_tx(c2,"T2",M1,"FAILED")); await asyncio.sleep(.30); blocked=not t2.done(); log(f"OBSERVED competing terminal blocked_after_300ms={blocked}"); assert_true(blocked,"second terminal did not block on conversation row")
    proceed.set(); r1=await t1; r2=await t2; await c1.close(); await c2.close()
    log(f"RAW winners={json.dumps([r1,r2])}")
    assert_true(sum(1 for r in [r1,r2] if r["won"])==1,"terminal transition had !=1 winner")
    await verify_uniqueness(11)


async def test12():
    await reset_data(); p=[u(1100+i) for i in range(1,7)]; mids=[m(120+i) for i in range(5)]
    pairs=[[p[0],p[3]],[p[1],p[3]],[p[1],p[4]],[p[2],p[4]],[p[2],p[5]]]
    await seed(p,mids)
    start=asyncio.Event()
    async def worker(i):
        c=await connect(f"W{i}"); tr=await begin(c,f"W{i}"); await start.wait()
        try:
            await acquire_pair(c,f"W{i}",mids[i],pairs[i],True); await asyncio.sleep(.10); await commit(tr,f"W{i}"); return ("ok",None)
        except asyncpg.PostgresError as exc:
            try: await rollback(tr,f"W{i}")
            except Exception: pass
            return ("err",exc.sqlstate)
        finally: await c.close()
    tasks=[asyncio.create_task(worker(i)) for i in range(5)]; start.set(); results=await asyncio.gather(*tasks); log(f"RAW stress_results={results}")
    assert_true(all(code != "40P01" for _,code in results),"canonical ordering produced a deadlock")
    assert_true(all(kind=="ok" or code=="23505" for kind,code in results),"unexpected canonical-order stress error")
    await verify_uniqueness(12)


async def test13():
    await reset_data(); A,B,C=u(1201),u(1202),u(1203); M1,M2=m(131),m(132)
    log(f"ROLE META M1 A={C} B={A}; M2 A={B} B={C}; canonical inserts sort UUID, not role")
    await seed([A,B,C],[M1,M2]); _,res=await concurrent_conflict(M1,[C,A],M2,[B,C])
    assert_true(not res["ok"] and res["error"].sqlstate=="23505","inverted role metadata bypassed canonical conflict")
    await verify_uniqueness(13)


async def test14():
    await reset_data(); A,B,C=u(1301),u(1302),u(1303); M1,M2=m(141),m(142)
    await seed([A,B,C],[M1,M2]); c1=await connect("T1"); c2=await connect("T2"); tr1=await begin(c1,"T1"); await insert_reservation(c1,"T1",M1,A)
    async def t2():
        tr2=await begin(c2,"T2")
        try:
            await acquire_pair(c2,"T2",M2,[A,C],True); await commit(tr2,"T2"); return ("ok",None)
        except asyncpg.PostgresError as exc:
            await rollback(tr2,"T2"); return ("err",exc.sqlstate)
    task=asyncio.create_task(t2()); await asyncio.sleep(.30); blocked=not task.done(); log(f"OBSERVED first-key blocked_after_300ms={blocked}"); assert_true(blocked,"first-key contender did not block")
    await insert_reservation(c1,"T1",M1,B); await commit(tr1,"T1"); result=await task; await c1.close(); await c2.close()
    assert_true(result==("err","23505"),f"unexpected first-key contender result {result}")
    await verify_uniqueness(14)


async def test15():
    await reset_data(); A,B,C=u(1401),u(1402),u(1403); M1,M2=m(151),m(152)
    await establish_pair(M1,[A,B],"ACTIVE"); await seed([C],[M2]); c=await connect("release"); await terminal_release_tx(c,"release",M1,"ENDED"); await c.close()
    c=await connect("new"); tr=await begin(c,"new"); await acquire_pair(c,"new",M2,[A,C],True); await commit(tr,"new"); await c.close()
    rows=await active_rows(A); active=sum(1 for r in rows if r["released_at"] is None); assert_true(len(rows)==2 and active==1,"historical+active shape incorrect")
    await verify_uniqueness(15)


async def test16():
    await reset_data(); A=u(1501); peers=[u(1502+i) for i in range(3)]; mids=[m(161+i) for i in range(3)]
    await seed([A]+peers,mids)
    for i,mid in enumerate(mids):
        c=await connect(f"acq{i}"); tr=await begin(c,f"acq{i}"); await acquire_pair(c,f"acq{i}",mid,[A,peers[i]],True); await commit(tr,f"acq{i}"); await c.close()
        c=await connect(f"rel{i}"); rr=await terminal_release_tx(c,f"rel{i}",mid,TERMINAL[i]); await c.close(); assert_true(rr["won"],"historical release failed")
    rows=await active_rows(A); assert_true(len(rows)==3 and all(r["released_at"] is not None for r in rows),"multiple released history rows invalid")
    await verify_uniqueness(16)


async def test17():
    await reset_data(); A,B=u(1601),u(1602); M1=m(171); await seed([A,B],[M1]); c=await connect("dup"); tr=await begin(c,"dup")
    await insert_reservation(c,"dup",M1,A)
    try:
        await insert_reservation(c,"dup",M1,A); raise InvariantFailure("duplicate same PK succeeded")
    except asyncpg.PostgresError as exc:
        log(f"RAW duplicate-pk ERROR={err_text(exc)}"); assert_true(exc.sqlstate=="23505","duplicate same PK did not yield 23505"); await rollback(tr,"dup")
    await c.close(); await verify_uniqueness(17)


async def test18():
    await reset_data(); A,B,C=u(1701),u(1702),u(1703); M1,M2=m(181),m(182); await seed([A,B,C],[M1,M2]); c=await connect("uniq"); tr=await begin(c,"uniq")
    await insert_reservation(c,"uniq",M1,A)
    try:
        await insert_reservation(c,"uniq",M2,A); raise InvariantFailure("duplicate active participant across matches succeeded")
    except asyncpg.PostgresError as exc:
        log(f"RAW partial-unique ERROR={err_text(exc)}"); assert_true(exc.sqlstate=="23505","cross-match active duplicate did not yield 23505"); await rollback(tr,"uniq")
    await c.close(); await verify_uniqueness(18)


async def test19():
    await reset_data(); A,B=u(1801),u(1802); M1=m(191); await seed([A,B],[M1]); c=await connect("rollback-both"); tr=await begin(c,"rollback-both")
    await acquire_pair(c,"rollback-both",M1,[A,B],True); await rollback(tr,"rollback-both"); await c.close(); rows=await active_rows(); assert_true(len(rows)==0,"both reservation inserts survived rollback")
    await verify_uniqueness(19)


async def test20():
    await reset_data(); A,B=u(1901),u(1902); M1=m(201); await establish_pair(M1,[A,B],"PENDING"); c=await connect("terminal-rollback"); tr=await begin(c,"terminal-rollback")
    await fetch(c,"terminal-rollback","UPDATE conversations SET conversation_status='ENDED' WHERE match_id=$1 AND conversation_status IN ('PENDING','ACTIVE','PAUSED') RETURNING conversation_status",M1)
    await fetch(c,"terminal-rollback","UPDATE participant_pairing_reservations SET released_at=clock_timestamp() WHERE match_id=$1 AND released_at IS NULL RETURNING participant_id::text",M1)
    await rollback(tr,"terminal-rollback"); await c.close(); c=await connect("inspect"); s=await fetch(c,"inspect","SELECT conversation_status FROM conversations WHERE match_id=$1",M1); r=await fetch(c,"inspect","SELECT count(*)::int AS active FROM participant_pairing_reservations WHERE match_id=$1 AND released_at IS NULL",M1); await c.close()
    assert_true(s[0]["conversation_status"]=="PENDING" and r[0]["active"]==2,"terminal rollback did not restore both status and reservations")
    await verify_uniqueness(20)


async def test21():
    await reset_data(); A,B=u(2001),u(2002); M1=m(211); await establish_pair(M1,[A,B],"ACTIVE"); writer=await connect("writer"); observer=await connect("observer"); tr=await begin(writer,"writer")
    await fetch(writer,"writer","UPDATE conversations SET conversation_status='ENDED' WHERE match_id=$1 AND conversation_status IN ('PENDING','ACTIVE','PAUSED') RETURNING conversation_status",M1)
    await fetch(writer,"writer","UPDATE participant_pairing_reservations SET released_at=clock_timestamp() WHERE match_id=$1 AND released_at IS NULL RETURNING participant_id::text",M1)
    before_s=await fetch(observer,"observer-before","SELECT conversation_status FROM conversations WHERE match_id=$1",M1); before_r=await fetch(observer,"observer-before","SELECT count(*)::int AS active FROM participant_pairing_reservations WHERE match_id=$1 AND released_at IS NULL",M1)
    assert_true(before_s[0]["conversation_status"]=="ACTIVE" and before_r[0]["active"]==2,"observer saw partial terminal transaction before commit")
    await commit(tr,"writer"); after_s=await fetch(observer,"observer-after","SELECT conversation_status FROM conversations WHERE match_id=$1",M1); after_r=await fetch(observer,"observer-after","SELECT count(*)::int AS active FROM participant_pairing_reservations WHERE match_id=$1 AND released_at IS NULL",M1)
    await writer.close(); await observer.close(); assert_true(after_s[0]["conversation_status"]=="ENDED" and after_r[0]["active"]==0,"observer did not see atomic terminal+release after commit")
    await verify_uniqueness(21)


async def held_status_test(test_no,status,base):
    await reset_data(); A,B,C=u(base),u(base+1),u(base+2); M1,M2=m(220+test_no),m(250+test_no); await establish_pair(M1,[A,B],status); await seed([C],[M2])
    c=await connect("reuse"); tr=await begin(c,"reuse")
    try:
        await acquire_pair(c,"reuse",M2,[A,C],True); raise InvariantFailure(f"{status} reservation was reusable")
    except asyncpg.PostgresError as exc:
        log(f"RAW[{status}] reuse ERROR={err_text(exc)}"); assert_true(exc.sqlstate=="23505",f"{status} reuse did not yield 23505"); await rollback(tr,"reuse")
    await c.close(); await verify_uniqueness(test_no)


async def test22(): await held_status_test(22,"PENDING",2101)
async def test23(): await held_status_test(23,"ACTIVE",2201)
async def test24(): await held_status_test(24,"PAUSED",2301)


async def test25():
    await reset_data(); A=u(2401); peers=[u(2402+i) for i in range(4)]; mids=[m(251+i) for i in range(4)]; next_peers=[u(2410+i) for i in range(4)]; next_mids=[m(261+i) for i in range(4)]
    await seed([A]+peers+next_peers,mids+next_mids)
    for i,status in enumerate(TERMINAL):
        c=await connect(f"acq-{status}"); tr=await begin(c,f"acq-{status}"); await acquire_pair(c,f"acq-{status}",mids[i],[A,peers[i]],True); await commit(tr,f"acq-{status}"); await c.close()
        c=await connect(f"rel-{status}"); rr=await terminal_release_tx(c,f"rel-{status}",mids[i],status); await c.close(); assert_true(rr["won"] and len(rr["released"])==2,f"{status} did not release both")
        c=await connect(f"reacq-{status}"); tr=await begin(c,f"reacq-{status}"); await acquire_pair(c,f"reacq-{status}",next_mids[i],[A,next_peers[i]],True); await commit(tr,f"reacq-{status}"); await c.close()
        c=await connect(f"cleanup-{status}"); rr2=await terminal_release_tx(c,f"cleanup-{status}",next_mids[i],"ENDED"); await c.close(); assert_true(rr2["won"],"cleanup terminal failed")
        await verify_uniqueness(25)


async def test26():
    await reset_data(); A,B=u(2501),u(2502); M1,M2=m(271),m(272); await establish_pair(M1,[A,B],"ACTIVE"); await seed([], [M2])
    c1=await connect("release-T1"); c2=await connect("newpair-T2"); hold=asyncio.Event(); proceed=asyncio.Event(); t1=asyncio.create_task(terminal_release_tx(c1,"release-T1",M1,"COMPLETED",hold,proceed)); await hold.wait()
    async def newpair():
        tr=await begin(c2,"newpair-T2")
        try:
            await acquire_pair(c2,"newpair-T2",M2,[A,B],True); await commit(tr,"newpair-T2"); return ("ok",None)
        except asyncpg.PostgresError as exc:
            await rollback(tr,"newpair-T2"); return ("err",exc.sqlstate)
    t2=asyncio.create_task(newpair()); await asyncio.sleep(.30); blocked=not t2.done(); log(f"OBSERVED full-pair reacquire blocked_after_300ms={blocked}"); assert_true(blocked,"full pair reacquire did not block")
    proceed.set(); r1=await t1; r2=await t2; await c1.close(); await c2.close(); assert_true(r1["won"] and r2==("ok",None),f"full pair release/reacquire result unexpected {r1} {r2}")
    await verify_uniqueness(26)


async def test27():
    await reset_data(); A=u(2601); M1=m(281); await seed([A],[M1]); c=await connect("check"); tr=await begin(c,"check")
    try:
        await sql(c,"check","INSERT INTO participant_pairing_reservations(match_id,participant_id,acquired_at,released_at) VALUES($1,$2,clock_timestamp(),clock_timestamp()-interval '1 second')",M1,A)
        raise InvariantFailure("released_at before acquired_at was accepted")
    except asyncpg.PostgresError as exc:
        log(f"RAW temporal-check ERROR={err_text(exc)}"); assert_true(exc.sqlstate=="23514","temporal check did not yield 23514"); await rollback(tr,"check")
    await c.close(); await verify_uniqueness(27)


async def test28():
    await reset_data(); pairs=[]; participants=[]; mids=[]
    for i in range(20):
        a=u(3000+i*2+1); b=u(3000+i*2+2); mid=m(300+i); participants += [a,b]; mids.append(mid); pairs.append([a,b])
    await seed(participants,mids); start=asyncio.Event()
    async def worker(i):
        c=await connect(f"S{i}"); tr=await begin(c,f"S{i}"); await start.wait()
        try:
            await acquire_pair(c,f"S{i}",mids[i],pairs[i],True); await asyncio.sleep(.05); await commit(tr,f"S{i}"); return "ok"
        finally: await c.close()
    tasks=[asyncio.create_task(worker(i)) for i in range(20)]; start.set(); results=await asyncio.gather(*tasks); log(f"RAW independent_stress successes={results.count('ok')} total={len(results)}")
    assert_true(len(results)==20 and all(r=="ok" for r in results),"independent stress did not fully succeed")
    await verify_uniqueness(28)


async def test29():
    await reset_data(); P,Q=u(4001),u(4002); M1,M2=m(391),m(392); await seed([P,Q],[M1,M2]); c1=await connect("NEG-T1"); c2=await connect("NEG-T2")
    await c1.execute("SET deadlock_timeout='200ms'"); await c2.execute("SET deadlock_timeout='200ms'")
    tr1=await begin(c1,"NEG-T1"); tr2=await begin(c2,"NEG-T2")
    log(f"NEGATIVE ORDER T1={[str(P),str(Q)]} T2={[str(Q),str(P)]}")
    await insert_reservation(c1,"NEG-T1-first",M1,P); await insert_reservation(c2,"NEG-T2-first",M2,Q)
    async def second(conn,label,mid,pid):
        try:
            await insert_reservation(conn,label,mid,pid); return ("ok",None)
        except asyncpg.PostgresError as exc:
            return ("err",exc)
    t1=asyncio.create_task(second(c1,"NEG-T1-second",M1,Q)); t2=asyncio.create_task(second(c2,"NEG-T2-second",M2,P)); await asyncio.sleep(.10)
    log(f"OBSERVED negative both_waiting_after_100ms={not t1.done() and not t2.done()}")
    r1,r2=await asyncio.gather(t1,t2)
    log(f"RAW negative second_results T1={r1[0]}:{err_text(r1[1]) if r1[1] else None} T2={r2[0]}:{err_text(r2[1]) if r2[1] else None}")
    deadlocks=sum(1 for kind,exc in [r1,r2] if kind=="err" and getattr(exc,"sqlstate",None)=="40P01")
    assert_true(deadlocks==1,"negative control did not produce exactly one 40P01 deadlock victim")
    for tr,label,result in [(tr1,"NEG-T1",r1),(tr2,"NEG-T2",r2)]:
        if result[0]=="ok":
            try: await commit(tr,label)
            except Exception as exc: log(f"RAW[{label}] commit error={err_text(exc)}")
        else:
            try: await rollback(tr,label)
            except Exception as exc: log(f"RAW[{label}] rollback after deadlock={err_text(exc)}")
    await c1.close(); await c2.close(); await verify_uniqueness(29)


TEST_FUNCS = {i: globals()[f"test{i}"] for i in range(1,30)}


async def environment_proof():
    conn=await connect("environment")
    try:
        rows=await fetch(conn,"environment","SELECT version() AS version, inet_server_addr()::text AS server_addr, inet_server_port() AS server_port, current_database() AS database_name, current_user AS database_user")
        row=dict(rows[0])
        log("ENVIRONMENT PROOF")
        log(f"github_event_name={os.environ.get('GITHUB_EVENT_NAME')}")
        log(f"github_run_id={os.environ.get('GITHUB_RUN_ID')}")
        log(f"github_runner_name={os.environ.get('RUNNER_NAME')}")
        log("database_source=github_actions_service_container_postgres_17")
        log(f"connection_target=127.0.0.1:5432/{row['database_name']}")
        log(f"database_user={row['database_user']}")
        log(f"server_addr={row['server_addr']} server_port={row['server_port']}")
        log(f"postgres_version={row['version']}")
        log("production_database_credentials_used=false")
        assert_true(os.environ.get("GITHUB_EVENT_NAME")=="workflow_dispatch","workflow was not manually dispatched")
        assert_true(row["database_name"]=="pairing_proof","unexpected database name")
    finally: await conn.close()


async def create_schema():
    conn=await connect("schema")
    try:
        log("SCRATCH SCHEMA SQL BEGIN")
        log(SCHEMA_SQL)
        log("SCRATCH SCHEMA SQL END")
        await conn.execute(SCHEMA_SQL)
        rows=await fetch(conn,"schema-verify","SELECT indexdef FROM pg_indexes WHERE tablename='participant_pairing_reservations' ORDER BY indexname")
        assert_true(any("WHERE (released_at IS NULL)" in r["indexdef"] or "WHERE released_at IS NULL" in r["indexdef"] for r in rows),"partial unique index missing")
    finally: await conn.close()


async def main():
    global _report
    os.makedirs(os.path.dirname(REPORT_PATH), exist_ok=True)
    with open(REPORT_PATH,"a",encoding="utf-8") as fh:
        _report=fh
        statuses={}
        try:
            await environment_proof()
            log("\nFROZEN DESIGN UNDER TEST")
            log("table=participant_pairing_reservations columns=match_id,participant_id,acquired_at,released_at(nullable)")
            log("primary_key=(match_id,participant_id); foreign_keys=match_id->matches, participant_id->participants")
            log("check=released_at IS NULL OR released_at >= acquired_at")
            log("partial_unique=UNIQUE(participant_id) WHERE released_at IS NULL")
            log("acquisition_order=ascending participant_id UUID")
            log("held_statuses=PENDING,ACTIVE,PAUSED")
            log("release_statuses=ENDED,ABANDONED,FAILED,COMPLETED")
            log("atomicity=release UPDATE in same winning transaction as terminal conversation status write")
            await create_schema()
            for i in range(1,30):
                log(f"\n===== TEST {i}: {TEST_NAMES[i]} =====")
                log(f"concurrent_sessions={CONCURRENT_SESSIONS[i]}; isolation=READ COMMITTED for every transaction")
                started=time.monotonic()
                try:
                    await TEST_FUNCS[i]()
                    statuses[i]="PASS"
                    log(f"TEST {i} PASS elapsed_ms={(time.monotonic()-started)*1000:.1f} expected_invariant_matched=true")
                except InvariantFailure as exc:
                    statuses[i]="FAIL"
                    log(f"TEST {i} FAIL invariant={exc}")
                    for j in range(i+1,30): statuses[j]="NOT EXECUTED — prior invariant failure stopped matrix"
                    raise
                except Exception as exc:
                    statuses[i]=f"NOT EXECUTED — harness blocker: {type(exc).__name__}: {exc}"
                    log(f"TEST {i} NOT EXECUTED blocker={err_text(exc)}")
                    log(traceback.format_exc())
                    for j in range(i+1,30): statuses[j]="NOT EXECUTED — prior harness blocker stopped matrix"
                    raise HarnessBlocked(str(exc)) from exc
            log("\nRESULTS SUMMARY")
            for i in range(1,30): log(f"TEST {i}: {statuses[i]}")
            log("FINAL_VERDICT=EXPERIMENTALLY_PROVEN")
            return 0
        except InvariantFailure:
            log("\nRESULTS SUMMARY")
            for i in range(1,30): log(f"TEST {i}: {statuses.get(i,'NOT EXECUTED — stopped')}")
            log("FINAL_VERDICT=FAILED")
            return 1
        except HarnessBlocked:
            log("\nRESULTS SUMMARY")
            for i in range(1,30): log(f"TEST {i}: {statuses.get(i,'NOT EXECUTED — stopped')}")
            log("FINAL_VERDICT=INCOMPLETE")
            return 2
        except Exception as exc:
            log(f"FATAL HARNESS ERROR={err_text(exc)}")
            log(traceback.format_exc())
            log("FINAL_VERDICT=INCOMPLETE")
            return 2


if __name__ == "__main__":
    rc=asyncio.run(main())
    sys.exit(rc)
